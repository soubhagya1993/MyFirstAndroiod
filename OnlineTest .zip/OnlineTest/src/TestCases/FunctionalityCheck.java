package TestCases;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FunctionalityCheck {
	WebDriver driver;
	Actions act;
	@BeforeTest
public void setUp()
{
	System.setProperty("webdriver.chrome.driver","C://Users//sidha//Downloads//Compressed//chromedriver.exe");
	driver= new ChromeDriver();
}
	@Test(priority=1)
public void Scenario1()
{
	driver.get("http://adjiva.com/qa-test/");
	String s2=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/legend/center/h2/b")).getText();
	if(s2.equals("Registration Form"))
	{
	System.out.println("--------Working Fine1---------");
    }
	else
	{
		System.out.println("--------Not Working---------");
	}
}
	 @Test(priority=2)
public void Scenario2()
{
   driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[10]/div/button")).click();
   String s5= driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[1]/div/small[2]")).getText();
   if(s5.equals("Please enter your First Name")){
   System.out.println("--------Working Fine2---------");
}
	 else
	 {
		 System.out.println("--------Not Working---------");
	 }
}
	 @Test(priority=3)
public void Scenario3()
{
	driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[1]/div/div/input")).sendKeys("A");
	String s=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[1]/div/small[1]")).getText();
	if(s.equals("This value is not valid"))
	{
	
	System.out.println("--------Working Fine3---------");
    }
	else
	{
	System.out.println("--------Not Working---------");
	}
}
	 @Test(priority=4)
public void Scenario4()
{
	 driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[1]/div/div/input")).sendKeys("Sidhartha");
	 String s18=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[1]/div/small[1]")).getText();
	 if(s18.equals("This value is not valid"))
	 {
	 System.out.println("--------Not Working---------"); 
	 }
	 else
	 {
	 System.out.println("--------Working Fine4---------");
	 }
}
	 @Test(priority=5)
public void Scenario5()
{
	driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[2]/div/div/input")).sendKeys("B");
	String s=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[2]/div/small[1]")).getText();
	if(s.equals("This value is not valid"))
	{
	System.out.println("--------Working Fine5---------");
    }
	else
	{
		System.out.println("--------Not Working---------");
	}
}
	 @Test(priority=6)
public void Scenario6()
{
		 driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[2]/div/div/input")).sendKeys("Mohanty");
		 String s6=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[2]/div/small[1]")).getText();
		 if(s6.equals("This value is not valid")){
		 System.out.println("--------Not Working---------");
		 }
		 else
		 {
			 System.out.println("--------Working Fine6---------");
		 }
}
	 @Test(priority=7)
public void Scenario7()
{
		WebElement wlt=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[3]/div/div/select"));
		Select sct= new Select(wlt);
		sct.selectByVisibleText("Engineering");
		String s8=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[3]/div/div/select/option[2]")).getText();
		if(s8.equals("Engineering"))
		{
		System.out.println("--------Working Fine7---------");
        }
		else
		{
			System.out.println("--------Not Working---------");
		}
		}
	 @Test(priority=8)
public void Scenario8()
{
         driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[4]/div/div/input")).click();	
         if(driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[4]/label/i")).isDisplayed())
         {
         System.out.println("--------Working Fine8---------");
         }
         else
         {
         System.out.println("--------Not Working---------");
         }
}
	 @Test(priority=9)
public void Scenario9()
{
		 driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[4]/div/div/input")).sendKeys("sidhar");
		 String s1=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[4]/div/small[1]")).getText();
		 if(s1.equals("This value is not valid"))
		 {
		 System.out.println("--------Working Fine9---------");
		 }
		 else
		 {
		 System.out.println("--------Not Working---------");
		 }
}
	 @Test(priority=10)
public void Scenario10()
{
		 WebElement wel=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[4]/div/div/input"));
		 wel.clear();
		 wel.sendKeys("sidhartha94");
		 String s7=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[4]/div/small[1]")).getText();
		 if(s7.equals("This value is not valid"))
		 {
		 System.out.println("--------Not Working---------");
		 }
		 else
		 {
		 System.out.println("--------Working Fine10---------");
		 }
}
	 @Test(priority=11)
public void Scenario11()
{
		 driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[5]/div/div/input")).click();
		 if(driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[5]/label/i")).isDisplayed())
		 {
		 System.out.println("--------Working Fine11---------");
		 }
		 else
		 {
		 System.out.println("--------Not Working---------");	 
		 }
}
	 @Test(priority=12)
public void Scenario12()
{
		 driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[5]/div/div/input")).sendKeys("943738");
		 String s2=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[5]/div/small[1]")).getText();
		 if(s2.equals("This value is not valid"))
		 {
		 System.out.println("--------Working Fine12---------");
		 }
		 else
		 {
		 System.out.println("--------Not Working---------");	 
		 }
}
	 @Test(priority=13)
public void Scenario13()
{
		 WebElement wel2=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[5]/div/div/input"));
		 wel2.clear();
		 wel2.sendKeys("9437383423");
		 String s9=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[5]/div/small[1]")).getText();
		 if(s9.equals("This value is not valid"))
		 {
		 System.out.println("--------Not Working---------");
		 }
		 else
		 {
		 System.out.println("--------Working Fine13---------");
		 }
}

	 @Test(priority=14)
public void Scenario14()
{
       driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[6]/div/div/input")).sendKeys("1234567890");
       String s10=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[6]/div/small[1]")).getText();
       if(s10.equals("This value is not valid"))
       {
       System.out.println("--------Working Fine14---------");
       }
       else
       {
       System.out.println("--------Not Working---------");
       }
}
	 @Test(priority=15)
public void Scenario15()
{
	  WebElement wel3=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[6]/div/div/input"));
	  wel3.clear();
	  wel3.sendKeys("9437383423");
	  String s11=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[6]/div/small[1]")).getText();
      if(s11.equals("This value is not valid"))
      {
      System.out.println("--------Not Working---------");
      }
      else
      {
      System.out.println("--------Working Fine15---------");
      }
}
	 @Test(priority=16)
public void Scenario16()
{
		driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[7]/div/div/input")).sendKeys("abcdefg"); 
		String s12=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[7]/div/small[2]")).getText();
		if(s12.equals("This value is not valid"))
		{
		System.out.println("--------Working Fine16---------");	
		}
		else
		{
		System.out.println("--------Not Working---------");	
		}
}
	 @Test(priority=17)
public void Scenario17() 
{
		 WebElement wel4=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[7]/div/div/input"));
		 wel4.clear();
		 wel4.sendKeys("abcdefghij");
		 String s13=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[7]/div/small[2]")).getText();
			if(s13.equals("This value is not valid"))
			{
			System.out.println("--------Working Fine17---------");
			}
			else
			{
			System.out.println("--------Not Working---------");	
			}	 
}
	 @Test(priority=18)
public void Scenario18()
{
	   WebElement wel5=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[7]/div/div/input"));
	   wel5.clear();
	   wel5.sendKeys("mohantysidhartha94@gmail.com");
	   String s14=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[7]/div/small[2]")).getText();
	       if(s14.equals("This value is not valid"))
	       {
	       System.out.println("--------Not Working---------"); 
	       }
	       else
	       {
	       System.out.println("--------Working Fine18---------");
	       }
}
	 @Test(priority=19)
public void Scenario19()
	 {
		driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[8]/div/div/input")).sendKeys("abcde");
		String s15=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[8]/div/small")).getText();
		if(s15.equals("This value is not valid"))
		{
		 System.out.println("--------Working Fine19---------");
		}
		else
		{
		 System.out.println("--------Not Working---------");
		}
	 }
	 @Test(priority=20)
public void Scenario20()
{
	WebElement wel6=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[8]/div/div/input"));
	 wel6.clear();
	 wel6.sendKeys("9437383423"); 
	String s16=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[8]/div/small")).getText();
	if(s16.equals("This value is not valid"))
	{
     System.out.println("--------Not Working---------");
	}
	else
	{
	 System.out.println("--------Working Fine20---------");
	}
}
	 @Test(priority=21)
public void Scenario21()
{
	driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/div[10]/div/button")).click();
	String s17=driver.findElement(By.xpath(".//*[@id='contact_form']/fieldset/legend/center/h2/b")).getText();
	if(s17.equals("Thanks"))
	{
    System.out.println("--------Working Fine21---------");
	}
	else
	{
	 System.out.println("--------Not Working---------");
	}
	driver.close();
}
	// @Test(priority=22)
/*public void Scenario22()
{
	driver.get("https://accounts.google.com/ServiceLogin/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=AddSession");
	driver.findElement(By.xpath(".//*[@id='identifierId']")).sendKeys("",Keys.ENTER);
	driver.findElement(By.xpath(".//*[@id='password']/div[1]/div/div[1]/input")).sendKeys("",Keys.ENTER);
	
	
}*/
	 
}

